# LDJ Press Brake Integration — Technical Brief

**Machine:** BLM SERIES 420-200, ESA/Kvara  
**Configuration:** No robot interface. Phase 1B (foot pedal sim) is the integration path.

---

## 1. System Distinction

Two separate I/O systems exist on the press:

| System | Addresses | Physical Location | Purpose |
|--------|-----------|-------------------|---------|
| ESA Rack (internal) | QW 1.x, QW 2.x, IW 0.x, IW 3.x | M.OUT1, M.OUT2, M.IN1, M.IN2 | Press internal I/O (CNC OK, Ram UP, clamping, drives) |
| BLM Robot Interface (optional) | E20.x, E21.x, E22.x, A20.x, A21.x, A22.x, A175.x, E169.x | XC2F, XC3M, XC4M — Weidmüller connectors | Full beam-level robot handshake per BLM spec |

The E20.x, A20.x, A175.x, E169.x addresses are **not** on the ESA PLC. They map to optional robot interface connectors. LDJ does not have this option.

```
ESA Rack (internal)                    BLM Robot Interface (optional)
-------------------                    ------------------------------
QW 1.6  CNC OK                        XC2F  E20.x E21.x E22.x  (Press -> Robot)
QW 2.4  Ram UP                        XC3M  A20.x A21.x        (Robot -> Press)
IW 0.12 Drive OK                      XC3M  A175.x E169.x      (Safety, dry contacts)
M1-167/168 Foot pedal                 XC4M  E22.x A22.x       (Tooling, program)
```

---

## 2. Address Clarification

| Address Range | Connector | Direction | Signal Type |
|---------------|-----------|-----------|-------------|
| E20.0–E20.7 | XC2F P3–P10 | Press → Robot | 24V status |
| E21.0–E21.6 | XC2F P11–P17 | Press → Robot | 24V status |
| E22.0–E22.3 | XC2F P18–19, XC4M P1–2 | Press → Robot | 24V status |
| A20.x, A21.x | XC3M P17–P24 | Robot → Press | 24V commands |
| A22.x | XC4M P3–P13 | Robot → Press | 24V (tool/program) |
| A175.0, E169.0/4 | XC3M P1–P16 | Bidirectional | Dry contacts (safety) |

**ESA rack (Phase 1B path):**

| ESA Address | Terminal | Signal |
|-------------|----------|--------|
| QW 1.6 | 15.D4 | CNC OK |
| QW 2.4 | 10.D4 | Ram UP (UDP) |
| IW 0.12 | 14.C6 | Drive OK |
| KP16.7/16.8 | M1-167 / M1-168 | Foot pedal (cycle trigger) |

---

## 3. Q&A

| Question | Answer | Source |
|----------|--------|--------|
| Is this a BLM doc or generated? | BLM. BLM Press-Brake Interface ver. 4.0 | robot_interface_reference.md L1-2 |
| E20.x, A20.x, A175.x, E169.x on ESA PLC? | No. They map to XC2F, XC3M, XC4M — optional robot interface. ESA uses QW/IW. | robot_interface_reference.md; LDJ_REF_Physical_IO_Terminal_Map |
| Why so many IO vs ESA few connectors? | Two systems. ESA = internal. E20.x/A20.x = optional robot interface. LDJ does not have it. | LDJ_REF_Physical_IO_Terminal_Map |
| Dener 7 circuits vs this? | Different manufacturer. BLM = 40+ signals. Dener = minimal. | robot_interface_reference.md |
| Additional cards? | No robot interface. Use foot pedal sim (M1-167/168) + ESA terminals. Add interface relays. | LDJ_REF_Physical_IO_Wiring_Spec; PHYSICAL_WIRING_OVERVIEW |

---

## 4. LDJ Path — Phase 1B

```
FANUC Robot  <->  Wago PLC  <->  Press (ESA terminals)
                    |
                    +-- DO -> M1-167/168 (Foot Pedal Sim)
                    +-- DI <- QW 1.6 (CNC OK)
                    +-- DI <- QW 2.4 (Ram UP)
                    +-- DI <- IW 0.12 (Drive OK)
```

**PLC outputs to press:**
- Foot Pedal Sim: M1-167 or M1-168 (parallel with KP16.7/KP16.8)
- 24V source: FE4.1 channel 4-6 (7.E0), 6A max
- 0V: OV4

**PLC inputs from press:**
- CNC OK: QW 1.6 → 15.D4
- Ram UP: QW 2.4 → 10.D4
- Drive OK: IW 0.12 → 14.C6
- Clamping Status: QW 1.13 → 15.D6 (optional)

**Wiring:** PLC relay NO contact in parallel with foot pedal. Use interface relays between PLC and press. Wire gauge 0.5–1.0 mm² (AWG 20–18).

---

## 5. Key Documents

| Document | Purpose |
|----------|---------|
| LDJ_Physical_IO_Terminal_Map | E20.x/A20.x → connector/pin; ESA QW/IW → M1/M2 |
| LDJ_Physical_IO_Wiring_Spec | Wiring checklist, 24V sourcing, isolation |
| LDJ_Integration_Index | File map, cross-reference table |
| Physical_Wiring_Overview | Phase 1A vs 1B, terminals |
| Integration_Flow | PHASE 0-6 cycle (1A), 12-step (1B) |
| Press_Brake_Reference | ESA rack I/O (Sec 6), M1/M2 (Sec 12), robot integration (Sec 13) |
