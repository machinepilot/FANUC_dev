# Robot Interface Optional — Reference

**Purpose:** Reference if Phase 1B insufficient or BLM retrofit pursued.  
**Source:** BLM Press-Brake Interface ver. 4.0 (robot_interface_reference.md)

---

## Connectors

| Connector | Function | Weidmüller Part Numbers |
|-----------|----------|-------------------------|
| XC2F | Power + Status I/O | 1745850000 + 121240000 |
| XC3M | Safety + Commands | 1745790000 + 121240000 |
| XC4M | Tooling + Program | 1745780000 + 1208600000 |

---

## Signal Set

**Press → Robot (inputs):** E20.x, E21.x, E22.x — beam position, finger sensors, axis status, tooling  
**Robot → Press (outputs):** A20.x, A21.x — beam commands, reset signals  
**Tooling/Program:** A22.x — tool change, program selection  
**Safety (dry contacts):** A175.x (emergency), E169.x (enable, fence)

---

## BLM Contact

**BLM Group / STR s.r.l.** — Request "Robotic interface optional" kit, wiring diagram, and installation instructions. BLM Manual Chapter 03-19.
