LDJ Controls Engineer Dossier
BLM Press Brake + FANUC Robot Integration

Zip this folder and send to your controls engineer.

START HERE: 00_OVERVIEW.md

This dossier contains all documentation needed for:
- Phase 1A: XC2F/XC3M/XC4M robot interface (beam-level control)
- Phase 1B: Foot pedal sim (alternative)
- Phase 2: Modbus TCP (program load, mode, parameters)

Reading order:
1. 00_OVERVIEW.md - Master overview, Modbus setup, limitations
2. 01_robot_interface_reference.md - Full signal set, PHASE 0-6 cycle
3. 02_LDJ_INTEGRATION_INDEX.md - Cross-reference
4. 03_INTEGRATION_FLOW.md - Signal flow
5. 04_PHYSICAL_WIRING_OVERVIEW.md - Wiring summary
6. reference/ - Detailed specs
7. modbus_register_map/ - Modbus register CSVs
8. examples/ - FANUC TP patterns

CRITICAL: Modbus cannot complete the full robot cycle. Hardwire is required for beam control and safe entry (Ram UP, End of Bend). See 00_OVERVIEW.md Section 5.6.
