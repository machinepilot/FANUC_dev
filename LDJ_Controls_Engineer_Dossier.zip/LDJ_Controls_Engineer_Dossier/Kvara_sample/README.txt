ServerModbus.xml - Sample Configuration

This file is extracted from the press brake Kvara/Exe folder for reference.

To accept external Modbus TCP connections, modify the IPAddr element:

  DEFAULT (localhost only):
    <IPAddr>127.0.0.1</IPAddr>

  OPTION A (listen on all interfaces):
    <IPAddr>0.0.0.0</IPAddr>

  OPTION B (bind to specific NIC):
    <IPAddr>172.16.0.51</IPAddr>

Location on press: Typically Kvara/Exe/ServerModbus.xml on the ESA controller.
Backup the original before editing.
Restart ESA/Kvara after changes.

See 00_OVERVIEW.md Section 5.3 for full details.
